namespace Project_mod2;

public class SortGeneration
{
    /// <summary>
    /// Класс, реализующий сортировку в списке объектов класса Pokemon по полю Generation.
    /// </summary>
    /// <param name="pokemons">Список объектов класса Pokemon.</param>
    public void SortG(List<Pokemon> pokemons)
    {
        Dictionary <int, List<Pokemon>> generations = new Dictionary <int, List<Pokemon>>();

        foreach (Pokemon pokemon in pokemons)
        {
            if (!generations.ContainsKey(pokemon.Generation))   //Проверка на наличие поколения покемона в списке словаря.
            {
                generations[pokemon.Generation] = new List<Pokemon>();
            }
            generations[pokemon.Generation].Add(pokemon);
        }

        foreach (KeyValuePair<int, List<Pokemon>> generation in generations)
        {
            int generationNumber = generation.Key;
            List<Pokemon> genPokemons = generation.Value;
            
            Pokemon strongestPokemon = null;
            foreach (Pokemon pokemon in genPokemons)
            {
                if (strongestPokemon == null || pokemon.Attack > strongestPokemon.Attack)  //Поиск самого сильного покемона в каждом поколении.
                {
                    strongestPokemon = pokemon;
                }    
            }
            Console.WriteLine($"Самый сильный покемон поколения {generationNumber}:");
            Console.WriteLine(strongestPokemon);
            Console.WriteLine(GenerationInfo(generationNumber, genPokemons));
            

            PokemonReaderWriter writer = new PokemonReaderWriter();
            writer.WriteToCsv(genPokemons, @$"../../../../Pokemon-Gen-{generationNumber}.csv");
        }
    }
    
    
    /// <summary>
    ///  Метод, создающий строку - результат сортировки для вывода в консоль.
    /// </summary>
    /// <param name="generationNumber">Номер поколения.</param>
    /// <param name="genPokemons">Список объектов класса Pokemon, принадлежащих поколению generationNumber.</param>
    /// <returns>Результат сортировки.</returns>
    private string GenerationInfo(int generationNumber, List<Pokemon> genPokemons)
    {
        string generationInfo = $"Список покемонов поколения {generationNumber}\n";
        int cnt = 1;
        foreach (Pokemon pokemon in genPokemons)
        {
            generationInfo += ($"{cnt}, {pokemon}\n");
            cnt++;
        }
        return generationInfo;
    }
}