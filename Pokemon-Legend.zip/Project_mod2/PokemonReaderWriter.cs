namespace Project_mod2;

/// <summary>
/// Класс, реализующий считывание данных из файла csv, создание списка объектов класса Pokemon из этих данных и позволяющий записывать данные об объектах Pokemon в файлы csv.
/// </summary>
public class PokemonReaderWriter
{
    /// <summary>
    /// Метод считывает данные из csv файла и создает список объектов класса Pokemon.
    /// </summary>
    /// <param name="path">Путь к файлу.</param>
    /// <returns>Список объектов класса Pokemon.</returns>
    public List<Pokemon> ReadPokemon(string path)
    {
        List<Pokemon> pokemons = new List<Pokemon>();
        try
        {
            StreamReader sr = new StreamReader(path);
            sr.ReadLine();  //Считывание первой строки, чтобы исключить заголовки в создании объекта.

            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                string[] values = line.Split(",");  //Сохранение всех значений для объекта в массив.

                if (values.Length == 13)
                {   /* Присваивание значения каждому полю объекта Pokemon
                    за исключением номеров в файле csv (первый элемент в массиве values) */                                
                    string name = values[1];      
                    string type1 = values[2];
                    string type2 = values[3];
                    string total = values[4];      
                    string hp = values[5];
                    string attack = values[6];
                    string defense = values[7];
                    string sp_atk = values[8];
                    string sp_def = values[9];
                    string speed = values[10];
                    string generation = values[11];
                    string legendary = values[12];

                    pokemons.Add(new Pokemon(name, type1, type2, total, hp, attack, defense, sp_atk, sp_def, speed,
                        generation, legendary)); //Создание объекта класса Pokemon и добавление его в список.
                }
                else
                {
                    Console.WriteLine("Формат файла не соответствует структуре");
                    break;
                }
            }

            return pokemons;
        }
        catch (PathTooLongException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка: путь к файлу слишком длинный");
            Console.ResetColor();
            throw;
        }
        catch (FileNotFoundException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Ошибка: Файл не найден. {e.Message}");
            Console.ResetColor();
            throw;

        }
        catch (DirectoryNotFoundException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Ошибка: Файл не найден. {e.Message}");
            Console.ResetColor();
            throw;
        }
        catch (IOException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Возникла ошибка ввода-вывода. {e.Message}");
            Console.ResetColor();
            throw;
        }
        catch (NullReferenceException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Ошибка: Возникло null значение. {e.Message}");
            Console.ResetColor();
            throw;
        }
        catch (Exception e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Произошла непредвиденная ошибка: {e.Message}");
            Console.ResetColor();
            throw;
        }
    }
    
    /// <summary>
    /// Метод, записывающий данные об объектах класса Pokemon в файл csv.
    /// </summary>
    /// <param name="pokemons">Список объектов класса Pokemon.</param>
    /// <param name="filename">Путь к файлу для записи данных.</param>
    public void WriteToCsv(List<Pokemon> pokemons, string filename)
    {
        try
        {
            StreamWriter writer = new StreamWriter(filename);
            writer.WriteLine("#,Name,Type 1,Type 2,Total,HP,Attack,Defense,Sp. Atk,Sp. Def,Speed,Generation,Legendary");  //Заголовок.

            int cnt = 1;     //Счетчик для сохранения структуры исходного csv файла.
            foreach (Pokemon pokemon in pokemons)
            {
                writer.WriteLine($"{cnt},{pokemon.Name},{pokemon.Type1},{pokemon.Type2}," +
                                 $"{pokemon.Total},{pokemon.Hp},{pokemon.Attack},{pokemon.Defense}," +
                                 $"{pokemon.SpAtk},{pokemon.SpDef},{pokemon.Speed},{pokemon.Generation}," +
                                 $"{pokemon.Legendary}");
                cnt++;
            }
            writer.Close();  //Закрытие потока вывода.
        }
        catch (FileNotFoundException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Ошибка: Файл csv не найден. {e.Message}");
            Console.ResetColor();
            throw;

        }
        catch (DirectoryNotFoundException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Ошибка: Файл csv не найден. {e.Message}");
            Console.ResetColor();
            throw;
        }
        catch (IOException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Возникла ошибка ввода-вывода при записи данных в файл csv. {e.Message}");
            Console.ResetColor();
            throw;
        }
        catch (NullReferenceException e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Ошибка: Возникло null значение. {e.Message}");
            Console.ResetColor();
            throw;
        }
        catch (Exception e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Произошла непредвиденная ошибка: {e.Message}");
            Console.ResetColor();
            throw;
        }
    }
    
    /// <summary>
    /// Метод формирует данные о покемонах в строковый формат и выводит их в консоль.
    /// </summary>
    /// <param name="pokemons">Список объектов класса Pokemon.</param>
    public void PrintSorted(List<Pokemon> pokemons)
    {
        int cnt = 1;
        foreach (Pokemon pokemon in pokemons)
        {
            Console.WriteLine($"{cnt}. {pokemon}");
            cnt++;
        }    
    }
}
