namespace Project_mod2;

/// <summary>
/// Класс реализует 6 пункт меню и выводит данные о покемонах у которых разброс между атакой и защитой составляет более 15 единиц.
/// </summary>
/// <param name="pokemons">Список объектов класса Pokemon.</param>
public class AttackDefenseDifferense (List<Pokemon> pokemons)
{
    /// <summary>
    /// Метод создает выборку из покемонов, у которых разброс между атакой и защитой составляет более 15 единиц.
    /// </summary>
    /// <returns>Выборку покемонов по заданному параметру.</returns>
    public List<Pokemon> PokemonsDifferense()
    {
        List<Pokemon> pokemonsWithDifference = new List<Pokemon>();
        foreach (Pokemon pokemon in pokemons)
        {
            if (Math.Abs(pokemon.Defense - pokemon.Attack) > 15)
            {
                pokemonsWithDifference.Add(pokemon);
            }    
        }
        return pokemonsWithDifference;
    }
}