﻿//Медведская Мария Ильинична
//Группа 246-2
//Вариант 2
using System;
namespace Project_mod2;

public class Program
{
    public static void Main()
    {
        ConsoleKeyInfo keyToExit;
        do
        {
            Menu0();

            var choice = Console.ReadLine();
            if (choice == "1")
            {
                Console.WriteLine("Введите адрес файла ");
                string filePath = Console.ReadLine();
                PokemonReaderWriter reader = new PokemonReaderWriter();
                List<Pokemon> pokemons = reader.ReadPokemon(filePath);
                Console.ForegroundColor = ConsoleColor.Green; 
                Console.WriteLine("Данные успешно загружены!");
                Console.ResetColor(); 

                while (true)       
                {
                    Menu1();    //Меню после загрузки данных в файл.
                
                    var choice1 = Console.ReadLine();
                    switch (choice1)
                    {
                        case "1":    //Выбор 1 в меню.
                            
                            Console.Write("Введите путь к файлу: ");
                            filePath = Console.ReadLine();
                            reader = new PokemonReaderWriter();
                            pokemons = reader.ReadPokemon(filePath);
                            break;
                        
                        case "2":    //Выбор 2 в меню.
                            
                            SortLegendary sorterLeg = new SortLegendary();
                            sorterLeg.SortL(pokemons);
                            Console.ForegroundColor = ConsoleColor.Green; 
                            Console.WriteLine("Списки легендарных и нелегендарных покемонов сохранены в файлы " +
                                          "Pokemon-Legendary.csv и Pokemon-Usual.csv соотвественно");
                            Console.ResetColor(); 
                            break;
                        
                        case "3":   //Выбор 3 в меню.
                            
                            SortGeneration sorterGen = new SortGeneration();
                            sorterGen.SortG(pokemons);
                            Console.ForegroundColor = ConsoleColor.Green; 
                            Console.WriteLine("Списки покемонов, сортированным по поколениям сохранены в файлы " +
                                          "Pokemon-Gen-N.csv, где N- номер поколения");
                            Console.ResetColor(); 
                            break;
                        
                        case "4":   //Выбор 4 в меню.
                            
                            ShowSummaryStatistics(pokemons);
                            break;
                        
                        case "5":   //Выбор 5 в меню.
                            
                            Console.WriteLine("Программа завершена");
                            return;
                        case "6":
                            try
                            {
                                Console.WriteLine("Введите название файла, в который сохранится выборка");
                                string adress = Console.ReadLine();
                                AttackDefenseDifferense pokemonsAtkDef = new AttackDefenseDifferense(pokemons);
                                List<Pokemon> pokemonsDiff = pokemonsAtkDef.PokemonsDifferense(); //Список покемонов для выборки.
                                PokemonReaderWriter writer = new PokemonReaderWriter();
                                writer.PrintSorted(pokemonsDiff);  //Вывод выборки в консоль.
                                writer.WriteToCsv(pokemonsDiff, $@"../../../../{adress}.csv");
                                
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine($"Данные успешно загружены в файл {adress}.csv");
                                Console.ResetColor();
                            }
                            catch (FileNotFoundException e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red; 
                                Console.WriteLine("Данные некорректны");
                                Console.ResetColor();

                            }
                            catch (DirectoryNotFoundException e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red; 
                                Console.WriteLine("Данные некорректны");
                                Console.ResetColor();
                                break;
                            }

                            break;
                            
                        
                        default:   //Некорректный выбор.
                            Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                            break;
                    }
                }
            }
            else
            {
                Console.WriteLine("Сначала нужно загрузить данные");
                Console.WriteLine("Нажмите любую клавишу");
            }
            keyToExit = Console.ReadKey();
        } while (keyToExit.Key != ConsoleKey.Escape);  //Программа не завершает работу, если не нажата клавиша Escape.
    }

    /// <summary>
    /// Метод выводит сводное меню при первом входе в программу.
    /// </summary>
    private static void Menu0()
    {
        Console.WriteLine("\nМеню:");
        Console.WriteLine("1. Загрузить данные из файла");
        Console.WriteLine("2. Сортировать покемонов по легендарности");
        Console.WriteLine("3. Сортировать покемонов по поколению");
        Console.WriteLine("4. Показать сводную статистику по данным");
        Console.WriteLine("5. Выйти из программы");
        Console.WriteLine("6. Вывести на экран выборку покемонов, у которых разброс между атакой и защитой составляет более 15 единиц");
    }
    /// <summary>
    /// Метод выводит сводное меню после загрузки данных из файла.
    /// </summary>
    private static void Menu1()
    {
        Console.WriteLine("\nМеню:");
        Console.WriteLine("1. Изменить набор данных");
        Console.WriteLine("2. Сортировать покемонов по легендарности");
        Console.WriteLine("3. Сортировать покемонов по поколению");
        Console.WriteLine("4. Показать сводную статистику по данным");
        Console.WriteLine("5. Выйти из программы");
        Console.WriteLine("6. Вывести на экран выборку покемонов, у которых разброс между атакой и защитой составляет более 15 единиц");
    }
    /// <summary>
    /// Метод выводит сводное меню при выборе 4 номера в основном меню.
    /// </summary>
    private static void Menu4()
    {
        Console.WriteLine("\nПункт 4");
        Console.WriteLine("1. Общее количество покемонов по поколениям");
        Console.WriteLine("2. Самый мощный и самый слабый покемон");
        Console.WriteLine("3. Количество ядовитых жуков");
        Console.WriteLine("4. Количество покемонов второго поколения, у которых защита меньше 50");
        Console.WriteLine("5. Выйти");
    }

    /// <summary>
    /// Метод реализует 4 пункт основного меню, выводит меню и обрабатывает запрос.
    /// </summary>
    /// <param name="pokemons"></param>
    private static void ShowSummaryStatistics(List<Pokemon> pokemons)
    {
        while (true)
        {
            Menu4();
            var choice2 = Console.ReadLine();
            ShowSummary summary = new ShowSummary(pokemons); 
            switch (choice2)
            {
                case "1":   //Выбор 1 в меню пункта 4 из основного меню.
                {
                    summary.GenerationsCount();
                    break;
                }
                case "2":   //Выбор 2 в меню пункта 4 из основного меню.
                {
                    summary.ShowStrongestWeakest();
                    break;
                }
                case "3":    //Выбор 3 в меню пункта 4 из основного меню.
                {
                    summary.ShowPoisonousBugs();
                    break;
                }
                case "4":    //Выбор 4 в меню пункта 4 из основного меню.
                {
                    summary.GenerationSecondWeakPokemons();
                    break;
                }    
                case "5":    //Выбор 5 в меню пункта 4 из основного меню.
                {
                    return;
                }
                default:     //Некорректный выбор в меню пункта 4 из основного меню.
                {
                    Console.ForegroundColor = ConsoleColor.Red; 
                    Console.WriteLine("Некорректный выбор, попробуйте снова");
                    Console.ResetColor();
                    break;
                }
            }
        }    
    }
}    