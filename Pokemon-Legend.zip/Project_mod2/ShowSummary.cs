namespace Project_mod2;

/// <summary>
/// Класс, реализующий сбор общей статистики для списка объектов класса Pokemon.
/// </summary>
/// <param name="pokemons">Список объектов класса Pokemon.</param>
public class ShowSummary (List<Pokemon> pokemons)
{
    /// <summary>
    /// Метод считает количество покемонов в каждом поколении и выводит результат в консоль.
    /// </summary>
    public void GenerationsCount()
    {
        Dictionary<int,int> generationCounts = new Dictionary<int, int>();

        foreach (Pokemon pokemon in pokemons)
        {
            if (generationCounts.ContainsKey(pokemon.Generation))
            {
                generationCounts[pokemon.Generation]++;
            }
            else
            {
                generationCounts[pokemon.Generation] = 1;
            }
        }

        Console.WriteLine("Общее количество покемонов по поколениям:");
        foreach (KeyValuePair<int, int> genCount in generationCounts)
        {
            Console.WriteLine($"Поколение {genCount.Key}: {genCount.Value} покемонов");
        }
    }

    /// <summary>
    /// Метод реализует поиск самого сильного и слабого покемона по полю Attack и выводит результат в консоль.
    /// </summary>
    public void ShowStrongestWeakest()
    {
        Pokemon strongest = null;
        Pokemon weakest = null;

        foreach (Pokemon pokemon in pokemons)
        {
            if (strongest == null || pokemon.Attack > strongest.Attack)
            {
                strongest = pokemon;
            }

            if (weakest == null || pokemon.Attack < weakest.Attack)
            {
                weakest = pokemon;
            }

            Console.WriteLine($"Самый мощный покемон:\n {strongest}");
            Console.WriteLine($"Самый слабый покемон:\n {weakest}");
        }    
    }

    /// <summary>
    /// Метод выводит количество покемонов, являющихся ядовитыми жуками (Type 1/2 - Poison/Bug) и выводит результат в консоль.
    /// </summary>
    public void ShowPoisonousBugs()
    {
        int poisonousBugsCount = 0;
        
        foreach (Pokemon pokemon in pokemons)
        {
            if (pokemon.Type1.Contains("Poison") && pokemon.Type2.Contains("Bug"))
            {
                poisonousBugsCount++;
            }

            if (pokemon.Type1.Contains("Bug") && pokemon.Type2.Contains("Poison"))
            {
                poisonousBugsCount++;
            }
        }
        Console.WriteLine($"Количество ядовитых жуков: {poisonousBugsCount}");
    }

    /// <summary>
    /// Метод считает количество покемонов второго поколения с защитой меньше 50 и выводит результат в консоль.
    /// </summary>
    public void GenerationSecondWeakPokemons()
    {
        int generationSecondWeakCount = 0;

        foreach (Pokemon pokemon in pokemons)
        {
            if (pokemon.Defense < 50)
            {
                generationSecondWeakCount++;
            }    
        }
        Console.WriteLine($"Количество покемонов второго поколения с защитой меньше 50: {generationSecondWeakCount}");
    }
}