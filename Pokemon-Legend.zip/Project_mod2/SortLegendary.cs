namespace Project_mod2;

/// <summary>
/// Класс, реализующий сортировку в списке объектов класса Pokemon по полю Legendary.
/// </summary>
public class SortLegendary
{
    /// <summary>
    /// Сортирует объекты класса Pokemon по полю Legendary и записывает их в соответствующие файлы csv.
    /// </summary>
    /// <param name="pokemons">Список объектов класса Pokemon.</param>
    public void SortL(List<Pokemon> pokemons)
    {
        List<Pokemon> legendaryPokemons = new List<Pokemon>();  //Список объектов класса Pokemon, являющихся легендарными.
        List<Pokemon> usualPokemons = new List<Pokemon>();    //Список объектов класса Pokemon, являющихся нелегендарными.

        foreach (Pokemon pokemon in pokemons)
        {
            if (pokemon.Legendary)
            {
                legendaryPokemons.Add(pokemon);
            }
            else
            {
                usualPokemons.Add(pokemon);
            }
        }

        Console.WriteLine(LegendaryInfo(legendaryPokemons, usualPokemons));
        
        PokemonReaderWriter writer = new PokemonReaderWriter();
        writer.WriteToCsv(legendaryPokemons, @$"../../../../Pokemon-Legendary.csv");
        writer.WriteToCsv(usualPokemons, @$"../../../../Pokemon-Usual.csv");
        
    }

    /// <summary>
    /// Метод, создающий строку - результат сортировки для вывода в консоль.
    /// </summary>
    /// <param name="legendaryPokemons">Список объектов класса Pokemon, являющихся легендарными.</param>
    /// <param name="usualPokemons">Список объектов класса Pokemon, являющихся нелегендарными.</param>
    /// <returns>Результат сортировки.</returns>
    private string LegendaryInfo(List<Pokemon> legendaryPokemons, List<Pokemon> usualPokemons)
    {
        int cnt = 1;
        string legendaryInfo = string.Empty;
        legendaryInfo += $"Количество легендарных покемонов: {legendaryPokemons.Count}\n";
        foreach (Pokemon pokemon in legendaryPokemons)
        {
            legendaryInfo += ($"{cnt} {pokemon}\n");
            cnt++;
        }

        cnt = 1;   //Обновление счетчика для нелегендарных покемонов.
        
        legendaryInfo += $"Количество нелегендарных покемонов: {usualPokemons.Count}\n";
        foreach (Pokemon pokemon in usualPokemons)
        {
            legendaryInfo += ($"{cnt} {pokemon}\n");
            cnt++;
        }
        return legendaryInfo;
    }
}