namespace Project_mod2;

/// <summary>
/// Класс Pokemon, создающий обЪект Pokemon с полями Name, Type 1, Type 2, Total, Hp, Attack, Defense, Sp. Atk, Sp. Def, Speed, Generation, Legendary.
/// </summary>
public class Pokemon
{
   public string Name { get; set; }
   public string Type1 { get; set; }
   public string Type2 { get; set; }
   public int Total { get; set; }
   public int Hp { get; set; }
   public int Attack { get; set; }
   public int Defense { get; set; }
   public int SpAtk { get; set; }
   public int SpDef { get; set; }
   public int Speed { get; set; }
   public int Generation { get; set; }
   public bool Legendary { get; set; }

   /// <summary>
   /// Конструктор класса Pokemon.
   /// </summary>
   /// <param name="name">Name</param>
   /// <param name="type1">Type 1</param>
   /// <param name="type2">Type 2</param>
   /// <param name="total">Total</param>
   /// <param name="hp">Hp</param>
   /// <param name="attack">Attack</param>
   /// <param name="defense">Defense</param>
   /// <param name="sp_atk">Sp. Atk</param>
   /// <param name="sp_def">Sp. Def</param>
   /// <param name="speed">Speed</param>
   /// <param name="generation">Generation</param>
   /// <param name="legendary">Legendary</param>
   public Pokemon(string name, string type1, string type2, string total, string hp, string attack, string defense, string sp_atk, string sp_def, string speed, string generation, string legendary)
   {
      try
      {
         Name = name;
         Type1 = type1;
         Type2 = type2;
         Total = int.Parse(total);
         Hp = int.Parse(hp);
         Attack = int.Parse(attack);
         Defense = int.Parse(defense);
         SpAtk = int.Parse(sp_atk);
         SpDef = int.Parse(sp_def);
         Speed = int.Parse(speed);
         Generation = int.Parse(generation);
         Legendary = bool.Parse(legendary);
         
      }
      catch (ArgumentNullException e)
      {
         Console.WriteLine(e.Message);
         throw;
      }
      catch (FormatException e)
      {
         Console.WriteLine(e.Message);
         throw;
      }
      catch (OverflowException e)
      {
         Console.WriteLine(e.Message);
         throw;
      }
   }

   /// <summary>
   /// Создание строки данных об объекте Pokemon при его вызове.
   /// </summary>
   /// <returns>Полная характеристика объекта.</returns>
   public override string ToString() => $"Name: {Name}, Type 1: {Type1}, Type 2: {Type2}, " +
                                        $"Total: {Total}, Hp: {Hp}, Attack: {Attack}, Defense: {Defense}," +
                                        $" Sp. Attack: {SpAtk}, Sp. Defense: {SpDef}, Speed: {Speed}," +
                                        $" Generation: {Generation}, Legendary: {Legendary}";
   ~Pokemon() { }  //Деструктор.
}